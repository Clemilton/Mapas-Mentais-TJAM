<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1564344728949" ID="ID_1134659309" LINK="main.mm" MODIFIED="1564345057347" TEXT="Munic&#xed;pios do Amazonas">
<node CREATED="1564345143613" FOLDED="true" ID="ID_1530239720" MODIFIED="1564345461330" POSITION="right" TEXT="05 munic&#xed;pios com MAIOR &#xe1;rea">
<node CREATED="1564345415102" ID="ID_873182813" MODIFIED="1564345442025">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="maior_areas.png" />
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1564345155150" FOLDED="true" ID="ID_1789701535" MODIFIED="1564345488782" POSITION="right" TEXT="05 Munic&#xed;pios com MENOR &#xe1;rea">
<node CREATED="1564345483465" ID="ID_1948161178" MODIFIED="1564345487584">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="menor_area.png" />
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1564345228810" FOLDED="true" ID="ID_1253154781" MODIFIED="1564345500995" POSITION="right" TEXT="05 Munic&#xed;pios MAIS PR&#xd3;XIMOS da Capital">
<node CREATED="1564345472977" ID="ID_378202082" MODIFIED="1564345499723">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="mais_proximos.png" />
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1564345288751" FOLDED="true" ID="ID_239293207" MODIFIED="1564345804773" POSITION="right" TEXT="05 Munic&#xed;pios MAIS DISTANTES da Capital">
<node CREATED="1564345511931" ID="ID_2573719" MODIFIED="1564345515000">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="mais_distantes.png" />
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</map>
