<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1564345817465" ID="ID_1085598998" LINK="main.mm" MODIFIED="1564345834251" TEXT="Faixa de Fronteira">
<node CREATED="1564345878059" ID="ID_820838051" MODIFIED="1564345904831" POSITION="right" TEXT="A C.F/88 considera faixa de fronteira uma largura de 150 km ao longo das fronteiras terrestres. "/>
<node CREATED="1564345904833" FOLDED="true" ID="ID_280731778" MODIFIED="1564346252310" POSITION="right" TEXT="essas &#xe1;rea est&#xe1; sujeita a regras especiais ">
<node CREATED="1564346221128" ID="ID_1318489643" MODIFIED="1564346235371" TEXT="de uso do solo"/>
<node CREATED="1564346235793" ID="ID_370361466" MODIFIED="1564346250001" TEXT="de propriedade"/>
<node CREATED="1564346242913" ID="ID_1806145588" MODIFIED="1564346244296" TEXT="de explora&#xe7;&#xe3;o econ&#xf4;mica."/>
</node>
<node CREATED="1564345962273" ID="ID_1059541066" MODIFIED="1564346254002" POSITION="right" TEXT="Amazonas faz fronteiras com 03 Pa&#xed;ses">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1564345994393" ID="ID_1966130782" MODIFIED="1564346021445" TEXT="oeste com Peru"/>
<node CREATED="1564346030265" ID="ID_849070368" MODIFIED="1564346039259" TEXT="noroeste com a Col&#xf4;mbia"/>
<node CREATED="1564346039654" ID="ID_909003426" MODIFIED="1564346171457" TEXT="Norte com a Venezuela - Planalto das Guianas"/>
</node>
<node CREATED="1564346190426" FOLDED="true" ID="ID_1643491801" MODIFIED="1564346412251" POSITION="right" TEXT="Mun&#xed;cipios Fronteiri&#xe7;os (08)">
<node CREATED="1564346267773" ID="ID_1228975971" MODIFIED="1564346392796" TEXT="Imagem 01">
<node CREATED="1564346271400" ID="ID_247239102" MODIFIED="1564346305053">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="municipios_fronteira01.png" />
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1564346307451" ID="ID_1621420414" MODIFIED="1564346393769" TEXT="Imagem 02">
<node CREATED="1564346313182" ID="ID_793472008" MODIFIED="1564346390146">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="municipios_fronteira02.png" />
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node CREATED="1564346419340" ID="ID_1487890312" MODIFIED="1564346447632" POSITION="right" TEXT="Tr&#xed;plice Fronteira - S&#xe3;o Gabriel da Cachoeira">
<node CREATED="1564346449240" ID="ID_128088474" MODIFIED="1564346479406" TEXT="Brasil"/>
<node CREATED="1564346451874" ID="ID_424675106" MODIFIED="1564346483215" TEXT="Col&#xf4;mbia "/>
<node CREATED="1564346483775" ID="ID_1676570042" MODIFIED="1564346486624" TEXT="Venezuela"/>
</node>
<node CREATED="1564346489415" ID="ID_192299203" MODIFIED="1564346515839" POSITION="right" TEXT="Tabatinga e Let&#xed;cia">
<node CREATED="1564346517858" ID="ID_586176424" MODIFIED="1564346520649" TEXT="Cidades g&#xea;meas"/>
<node CREATED="1564346521322" ID="ID_1043454327" MODIFIED="1564346545460" TEXT="conviv&#xea;ncia cultural entre as pessoas que vivem ali."/>
</node>
<node CREATED="1564346572366" ID="ID_1065740840" MODIFIED="1564346585035" POSITION="left" TEXT="Colabora&#xe7;&#xe3;o e Seguran&#xe7;a"/>
<node CREATED="1564346585394" ID="ID_1202418077" MODIFIED="1564346599671" POSITION="left" TEXT="Vigil&#xe2;ncia nas Fronteiras"/>
<node CREATED="1564346599962" ID="ID_1883069103" MODIFIED="1564346614747" POSITION="left" TEXT="A&#xe7;&#xf5;es de Fronteira"/>
<node CREATED="1564346615647" ID="ID_1178472174" MODIFIED="1564346628004" POSITION="left" TEXT="Fronteiras e Povos ind&#xed;genas"/>
</node>
</map>
