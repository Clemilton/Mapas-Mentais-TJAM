<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1564482811316" ID="ID_716421729" MODIFIED="1564859965629" TEXT="Licen&#xe7;as(Art 65 &#xe0; 79)">
<edge COLOR="#665f74" STYLE="bezier" WIDTH="1"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1564482854846" ID="ID_537963289" MODIFIED="1564853544964" POSITION="right" STYLE="fork" TEXT="Defini&#xe7;&#xe3;o">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564482867612" ID="ID_1875499951" MODIFIED="1565920778583" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; Licen&#231;a --&gt; <u>afastamento total do servi&#231;o</u>&#160;--&gt; <b>car&#225;ter tempor&#225;rio</b>&#160;--&gt;<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ao funcion&#225;rio/servidor p&#250;blico.
    </p>
    <p>
      
    </p>
    <p>
      &gt; O servidor <u>aguardar&#225; em exerc&#237;cio</u>&#160;at&#233; que a licen&#231;a seja concedida;
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1564483003944" ID="ID_1015702875" MODIFIED="1564859907681" POSITION="right" TEXT="Tipos de Licen&#xe7;as">
<edge WIDTH="1"/>
<node COLOR="#0033ff" CREATED="1564483013503" ID="ID_1701275057" MODIFIED="1565920626271" TEXT="por MOTIVO DE SA&#xda;DE">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1564483487455" ID="ID_1176106122" MODIFIED="1564483524259" TEXT="Art 68"/>
<node COLOR="#006699" CREATED="1564483491455" ID="ID_1811443835" MODIFIED="1564483524259" TEXT="Depende de Inspe&#xe7;&#xe3;o M&#xe9;dica"/>
<node CREATED="1564483529884" ID="ID_1702854099" MODIFIED="1564483829936" TEXT="Readapta&#xe7;&#xe3;o do Funcion&#xe1;rio">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564483576830" ID="ID_400101589" MODIFIED="1564853733159" TEXT="Quando a inspe&#xe7;&#xe3;o m&#xe9;dica verificar -&gt;">
<arrowlink DESTINATION="ID_1702854099" ENDARROW="Default" ENDINCLINATION="169;-36;" ID="Arrow_ID_1447062207" STARTARROW="None" STARTINCLINATION="-106;-39;"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564483592936" ID="ID_802165429" MODIFIED="1564690258354" TEXT="&gt; Redu&#xe7;&#xe3;o da capacidade f&#xed;sica do funcion&#xe1;rio">
<arrowlink DESTINATION="ID_1151731631" ENDARROW="Default" ENDINCLINATION="167;0;" ID="Arrow_ID_642429594" STARTARROW="None" STARTINCLINATION="167;0;"/>
</node>
<node COLOR="#0033ff" CREATED="1564483620146" ID="ID_856038204" MODIFIED="1564690239164" TEXT="&gt; Estado de sa&#xfa;de a impossibilitar ou">
<arrowlink DESTINATION="ID_1151731631" ENDARROW="Default" ENDINCLINATION="215;0;" ID="Arrow_ID_751190861" STARTARROW="None" STARTINCLINATION="215;0;"/>
</node>
<node COLOR="#0033ff" CREATED="1564483638492" ID="ID_500738655" MODIFIED="1564690255622" TEXT="&gt; desaconselhar os exerc&#xed;cios da fun&#xe7;&#xe3;o inerentes ao seu cargo">
<arrowlink DESTINATION="ID_1151731631" ENDARROW="Default" ENDINCLINATION="45;0;" ID="Arrow_ID_23045681" STARTARROW="None" STARTINCLINATION="45;0;"/>
</node>
<node COLOR="#338800" CREATED="1564483670171" ID="ID_1151731631" MODIFIED="1564853719624" STYLE="bubble" TEXT="e n&#xe3;o se configurar necessidade de aposentadoria nem licen&#xe7;a">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#ff0000" CREATED="1564483846355" ID="ID_124113482" MODIFIED="1564483922317" TEXT="O funcion&#xe1;rio licenciado para tratamento de sa&#xfa;de n&#xe3;o pode fazer a qualquer atividade remunerada">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1564483874567" ID="ID_938040811" MODIFIED="1564483928451" TEXT="sob pena de imediata suspens&#xe3;o da licen&#xe7;a, "/>
<node COLOR="#ff0000" CREATED="1564483889991" ID="ID_1152463020" MODIFIED="1564483928451" TEXT="com perda total de vencimento e vantagens,"/>
<node COLOR="#ff0000" CREATED="1564483895841" ID="ID_1699442083" MODIFIED="1564483928451" TEXT="at&#xe9; reassumir o cargo ."/>
</node>
<node COLOR="#0033ff" CREATED="1564483502033" ID="ID_847370259" MODIFIED="1564853754316" TEXT="Sem preju&#xed;zo da remunera&#xe7;&#xe3;o">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1564483030959" HGAP="21" ID="ID_1867700610" MODIFIED="1565920644387" TEXT="por MOTIVO DE DOEN&#xc7;A EM PESSOA DA FAM&#xcd;LIA" VSHIFT="9">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1564483943276" ID="ID_328686495" MODIFIED="1564483969380" TEXT="Art 72">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564483969638" ID="ID_1826340215" MODIFIED="1564853783148" TEXT="Sem preju&#xed;zo da remunera&#xe7;&#xe3;o">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564483984562" ID="ID_1051929371" MODIFIED="1564854179212" TEXT="Para parentes">
<node COLOR="#338800" CREATED="1564484016034" ID="ID_1280471767" MODIFIED="1564484504446" TEXT="Cosangu&#xed;neos">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#338800" CREATED="1564484022903" ID="ID_1972387287" MODIFIED="1564484504446" TEXT="At&#xe9; segundo Grau">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#338800" CREATED="1564484054948" ID="ID_468976522" MODIFIED="1564484504446" TEXT="C&#xf4;njuge ou companheiro">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1564484082593" ID="ID_1944934436" MODIFIED="1564853798162" TEXT="&gt; somente quando">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564484099314" ID="ID_1438794507" MODIFIED="1564484498032" TEXT="provado que a sua assist&#xea;ncia pessoal &#xe9; indispens&#xe1;vel">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564484108439" ID="ID_730524099" MODIFIED="1564484498032" TEXT="n&#xe3;o pode ser prestada sem se afastar da reparti&#xe7;&#xe3;o.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1564484120280" ID="ID_33888304" MODIFIED="1564488658612" TEXT="Prazos">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564484123082" ID="ID_1417285182" MODIFIED="1564488623986" TEXT="&gt; a licen&#xe7;a depender&#xe1; de inspe&#xe7;&#xe3;o pela junta m&#xe9;dica oficial -&gt; ">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564484224298" ID="ID_1387053576" MODIFIED="1564484537438" TEXT="avaliar&#xe1; e definir&#xe1; o prazo da concess&#xe3;o"/>
<node COLOR="#0033ff" CREATED="1564484231900" ID="ID_1649683691" MODIFIED="1564484539160" TEXT=" de acordo com a gravidade do caso."/>
</node>
<node COLOR="#0033ff" CREATED="1564484244870" ID="ID_7828269" MODIFIED="1564488628357" TEXT="&gt; poder&#xe3;o ser concedidas prorroga&#xe7;&#xf5;es">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564484264497" ID="ID_1617063852" MODIFIED="1564488633867" TEXT="&gt; precedidas de per&#xed;cia m&#xe9;dica oficial -&gt; a quem cabe fixar o novo prazo da licen&#xe7;a.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564484287113" ID="ID_1822516463" MODIFIED="1564488640693" TEXT="&gt; Tratamento fora do estado">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564484321159" ID="ID_1930572555" MODIFIED="1564484573837" TEXT="para fins de prorroga&#xe7;&#xe3;o da licen&#xe7;a"/>
<node COLOR="#0033ff" CREATED="1564484331248" ID="ID_578544977" MODIFIED="1564484573837" TEXT="dever&#xe1; apresentar laudo do m&#xe9;dico respons&#xe1;vel para exame da junta m&#xe9;dica oficial."/>
</node>
<node COLOR="#0033ff" CREATED="1564484358105" ID="ID_936661840" MODIFIED="1564488656644" TEXT="&gt; Cura ou Falecimento do Familiar">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1564484388079" ID="ID_1652284455" MODIFIED="1564853840252" STYLE="bubble" TEXT="Servidor deve retornar as suas fun&#xe7;&#xf5;es&#xa;sob pena de PAD e restitui&#xe7;&#xe3;o ao er&#xe1;rio">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1564483061799" ID="ID_1814054245" MODIFIED="1564483169062" TEXT="&#xe0; Gestante">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564483072820" FOLDED="true" ID="ID_1573552243" MODIFIED="1564860972841" TEXT="por Motivo de Afastamento do Conjuge">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564488728615" ID="ID_1040061304" MODIFIED="1564488841385" TEXT="SEM REMUNERA&#xc7;&#xc3;O">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564488842006" ID="ID_1799757997" MODIFIED="1564488936117" TEXT="Casos de Licen&#xe7;as">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#338800" CREATED="1564488874321" ID="ID_1300126438" MODIFIED="1564488921910" TEXT="Removido/Transferido p/ outro ponto do territ&#xf3;rio Nacional">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#338800" CREATED="1564488904414" ID="ID_341916456" MODIFIED="1564488923279" TEXT="Eleito p/ exercer mandato eletivo">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#338800" CREATED="1564488964144" ID="ID_1815677653" MODIFIED="1564489002069" TEXT="Caso haja reparti&#xe7;&#xe3;o estadual do &#xd3;rg&#xe3;o">
<node COLOR="#338800" CREATED="1564488988072" ID="ID_1132002992" MODIFIED="1564489002930" TEXT="O funcion&#xe1;rio nele ter&#xe1; exerc&#xed;cio"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1564483019257" FOLDED="true" ID="ID_1800485368" MODIFIED="1564860960225" TEXT="p/ tratamento de Interesses Particulares">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1564489011273" ID="ID_910579809" MODIFIED="1564489522122" TEXT="Art 75">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1564489021515" FOLDED="true" ID="ID_313775402" MODIFIED="1564859990332" TEXT="Defini&#xe7;&#xe3;o">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564489058007" ID="ID_473344073" MODIFIED="1564489156456" TEXT="&gt; A crit&#xe9;rio da Administra&#xe7;&#xe3;o, poder&#xe1; ser concedida licen&#xe7;a p/ tratar de interesses particulares"/>
<node COLOR="#0033ff" CREATED="1564489097515" ID="ID_1322643950" MODIFIED="1564489159455" TEXT="por per&#xed;odo fixado no ato concessivo">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1564489119228" ID="ID_1472562047" MODIFIED="1564489162390" TEXT="SEMPRE -&gt; SEM REMUNERA&#xc7;&#xc3;O">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1564489199677" ID="ID_1956852788" MODIFIED="1564489434152" TEXT="&gt; O Estatuto n&#xe3;o estabelece prazos para esse tipo de licen&#xe7;a"/>
<node COLOR="#0033ff" CREATED="1564489277990" ID="ID_930273100" MODIFIED="1564489438753" TEXT="&gt; pode ser interrompida a qualquer tempo">
<node COLOR="#338800" CREATED="1564489313971" ID="ID_1793302045" MODIFIED="1564489443240" TEXT="a pedido do Servidor"/>
<node COLOR="#338800" CREATED="1564489322968" ID="ID_1872883410" MODIFIED="1564489443884" TEXT="a crit&#xe9;rio da Administra&#xe7;&#xe3;o"/>
</node>
<node COLOR="#0033ff" CREATED="1564489329362" ID="ID_603815875" MODIFIED="1564489458644" TEXT="&gt; Prorroga&#xe7;&#xe3;o da Licen&#xe7;a">
<node COLOR="#338800" CREATED="1564489361861" ID="ID_81243166" MODIFIED="1564489500163" TEXT="por requerimento do servidor interessado"/>
<node COLOR="#338800" CREATED="1564489401414" ID="ID_566169527" MODIFIED="1564489502248" TEXT="pessoalmente ou por procurador com poderes especiais"/>
</node>
<node COLOR="#0033ff" CREATED="1564489415510" ID="ID_560575773" MODIFIED="1564489486054" TEXT="&gt; A licen&#xe7;a suspende o v&#xed;nculo do servidor com a Administra&#xe7;&#xe3;o , n&#xe3;o se computando o tempo correspondente para qualquer efeito , inclusive o de est&#xe1;gio probat&#xf3;rio.">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1564483131836" ID="ID_1601092873" MODIFIED="1564860983341" TEXT="p/ Servi&#xe7;o Militar Obrigat&#xf3;rio">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1564489527903" ID="ID_1223718327" MODIFIED="1564690410327" TEXT="Art 76">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1564860332651" ID="ID_1142571474" MODIFIED="1564860671703" STYLE="bubble" VSHIFT="9">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      A licen&#231;a ser&#225; concedida &#224; <u><b>vista de</b></u><b><br /><u>&#160;documento que prove a incorpora&#231;&#227;o</u></b><br />e da remunera&#231;&#227;o descontar-se-&#225; a<br />import&#226;ncia que o funcion&#225;rio<br />perceber pelo servi&#231;o militar.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1564489773367" ID="ID_581305314" MODIFIED="1564860666135" STYLE="bubble" VSHIFT="18">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Funcion&#225;rio Oficial da Reserva tem LICEN&#199;A REMUNERADA
    </p>
    <ul>
      <li>
        Quando pelo servi&#231;o militar n&#227;o perceber vantagem pecuni&#225;ria.
      </li>
      <li>
        Quando o est&#225;gio for remunerado tem direito de op&#231;&#227;o.
      </li>
    </ul>
  </body>
</html></richcontent>
</node>
<node COLOR="#0033ff" CREATED="1564489839405" ID="ID_1418344888" MODIFIED="1564860662686" STYLE="bubble" VSHIFT="16">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ocorrido o desligamento do servi&#231;o militar
    </p>
    <p>
      &#160;&#160;&#160;&#160; <font color="#ff0024">&gt; O funcion&#225;rio ter&#225; prazo de 30 dias </font>
    </p>
    <p>
      <font color="#ff0024">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;p/ reassumir o exerc&#237;cio</font>
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#0033ff" CREATED="1564483147579" FOLDED="true" ID="ID_333432277" MODIFIED="1564860279263" TEXT="Especial">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1564489959016" ID="ID_1045900984" MODIFIED="1564490400839" TEXT="Art 78">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564854253527" ID="ID_633293659" MODIFIED="1564854264678" TEXT="&gt; Licen&#xe7;a Remunerada">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1564490023156" ID="ID_1689569566" MODIFIED="1564490460948" TEXT="&gt; Ap&#xf3;s cada quinqu&#xea;nio de efetivo exerc&#xed;cio">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564490036118" ID="ID_1229083443" MODIFIED="1564490467973" TEXT="o funcion&#xe1;rio far&#xe1; jus &#xe0; licen&#xe7;a especial de 03 meses"/>
<node COLOR="#0033ff" CREATED="1564490044252" ID="ID_258807224" MODIFIED="1564490467973" TEXT="com todos os direitos e vantagens do seu cargo efetivo"/>
<node COLOR="#0033ff" CREATED="1564490053061" ID="ID_1624471553" MODIFIED="1564490467973" TEXT="podendo acumular o per&#xed;odo de 02 quinqu&#xea;nios."/>
</node>
<node COLOR="#0033ff" CREATED="1564490094654" ID="ID_429964424" MODIFIED="1564490461579" TEXT="&gt; Se funcion&#xe1;rio efetivo em cargo de comiss&#xe3;o/fun&#xe7;&#xe3;o gratificada">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564490125369" ID="ID_884978552" MODIFIED="1564490477511" TEXT="&gt; ter&#xe1; direito :"/>
<node COLOR="#0033ff" CREATED="1564490152050" ID="ID_233226116" MODIFIED="1564490482092" TEXT="     das vantagens financeiras do cargo em comiss&#xe3;o ou da fun&#xe7;&#xe3;o gratificada que ocupar."/>
</node>
<node COLOR="#0033ff" CREATED="1564490237829" ID="ID_158997330" MODIFIED="1564490462065" TEXT="&gt; As faltas injustificadas ao servi&#xe7;o RETARDAR&#xc3;O a concess&#xe3;o da licen&#xe7;a, na propor&#xe7;&#xe3;o de 01 m&#xea;s para cada falta.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1564490243950" ID="ID_1934549661" MODIFIED="1564490412900" TEXT="N&#xe3;o ser&#xe1; concedido licen&#xe7;a">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1564490296555" ID="ID_1000229787" MODIFIED="1564490422172" TEXT="sofrido pena de multa ou suspens&#xe3;o;">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1564490330901" ID="ID_862881906" MODIFIED="1564490424982" TEXT="faltado ao servi&#xe7;o sem justifica&#xe7;&#xe3;o;">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1564490347927" ID="ID_673607849" MODIFIED="1564490424981" TEXT="gozado licen&#xe7;a:">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#338800" CREATED="1564490357617" ID="ID_452573020" MODIFIED="1564490439465" TEXT="para tratamento de sa&#xfa;de, por prazo superior a 180 dias , consecutivos ou n&#xe3;o;"/>
<node COLOR="#338800" CREATED="1564490363584" ID="ID_1705218153" MODIFIED="1564490442072" TEXT="para tratamento de sa&#xfa;de em pessoa da fam&#xed;lia, por prazo superior a 120 dias , consecutivos ou n&#xe3;o;"/>
<node COLOR="#338800" CREATED="1564490372305" ID="ID_407805646" MODIFIED="1564490442072" TEXT="para tratamento de interesses particulares;"/>
<node COLOR="#338800" CREATED="1564490378790" ID="ID_336500173" MODIFIED="1564490442067" TEXT="por motivo de afastamento do c&#xf4;njuge, funcion&#xe1;rio civil ou militar, por prazo superior a 60 dia, consecutivos ou n&#xe3;o."/>
</node>
</node>
</node>
</node>
<node CREATED="1564483190706" ID="ID_1366593348" MODIFIED="1564693757449" POSITION="left" TEXT="Destaques">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564483214951" ID="ID_1336879621" MODIFIED="1564483390686" TEXT="&gt; O funcion&#xe1;rio n&#xe3;o poder&#xe1; permanecer em licenciado por prazo superior a 24 meses">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1564483273371" ID="ID_584098961" MODIFIED="1564853654839" TEXT="SALVO, no caso de">
<node COLOR="#ff0000" CREATED="1564483290061" ID="ID_1292062234" LINK="#ID_1573552243" MODIFIED="1564488825779" TEXT="por motivo de Afastamento do Conjuge, funcion&#xe1;rio civil, militar, ou servidor de autarquia;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1564483329487" ID="ID_1875596450" LINK="#ID_1800485368" MODIFIED="1564483405014" TEXT="p/ tratamento de interesse particular"/>
<node COLOR="#ff0000" CREATED="1564483342572" ID="ID_1493866841" LINK="#ID_1601092873" MODIFIED="1564483405013" TEXT="p/ servi&#xe7;o militar obrigat&#xf3;rio"/>
</node>
<node COLOR="#0033ff" CREATED="1564483407054" ID="ID_1733860750" MODIFIED="1564488536906" TEXT="&gt; A licen&#xe7;a concedida dentro de 60 dias, ap&#xf3;s o t&#xe9;rmino da anterior, ser&#xe1; concedida como prorroga&#xe7;&#xe3;o">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</map>
