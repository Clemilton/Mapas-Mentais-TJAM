<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1564692826225" ID="ID_1107890984" MODIFIED="1564854316902" TEXT="Disponibilidade">
<edge COLOR="#f11be7"/>
<node COLOR="#006699" CREATED="1564692847920" HGAP="99" ID="ID_1677101393" MODIFIED="1564854354032" POSITION="right" VSHIFT="-38">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; &#201; o ato pelo qual o funcion&#225;rio est&#225;vel<br />fica afastado de qualquer atividade em virtude de:
    </p>
  </body>
</html></richcontent>
<node COLOR="#338800" CREATED="1564692872127" ID="ID_1244430030" MODIFIED="1564854358552" STYLE="bubble" TEXT="extin&#xe7;&#xe3;o do cargo" VSHIFT="3"/>
<node COLOR="#338800" CREATED="1564692879076" HGAP="14" ID="ID_27095330" MODIFIED="1564854360744" STYLE="bubble" TEXT="declara&#xe7;&#xe3;o da desnecessidade do seu cargo." VSHIFT="15"/>
</node>
<node COLOR="#006699" CREATED="1564692909750" HGAP="22" ID="ID_756638110" MODIFIED="1564854346800" POSITION="right" TEXT="&gt; O funcion&#xe1;rio em disponibilidade perceber&#xe1; -&gt;" VSHIFT="17">
<node COLOR="#338800" CREATED="1564693453439" ID="ID_1327643873" MODIFIED="1564854334689" STYLE="bubble" TEXT="proventos proporcionais ao seu tempo de servi&#xe7;o e"/>
<node COLOR="#338800" CREATED="1564693467509" ID="ID_1198176366" MODIFIED="1564854343272" STYLE="bubble" TEXT="as vantagens incorpor&#xe1;veis &#xe0; data da inativa&#xe7;&#xe3;o e o sal&#xe1;rio-fam&#xed;lia." VSHIFT="23"/>
</node>
<node COLOR="#006699" CREATED="1564693497990" ID="ID_704853971" MODIFIED="1564693523713" POSITION="right" TEXT="&gt; Caso o Cargo volte a existir">
<node COLOR="#338800" CREATED="1564693505681" HGAP="34" ID="ID_111029496" MODIFIED="1564854340049" STYLE="bubble" TEXT="ser&#xe1; nele aproveitado, com prioridade, o funcion&#xe1;rio que estiver em disponibilidade." VSHIFT="10"/>
</node>
</node>
</map>
