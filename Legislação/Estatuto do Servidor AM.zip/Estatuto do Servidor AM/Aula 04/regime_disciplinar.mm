<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1564858435173" ID="ID_74375404" MODIFIED="1565207167216" STYLE="bubble" TEXT="Regime Disciplinar">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1564858477182" HGAP="24" ID="ID_299246174" MODIFIED="1565207167216" POSITION="right" VSHIFT="-50">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Art 144 &#224; 172
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1564858556232" ID="ID_1777962483" MODIFIED="1565207167217" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Esses artigos versam sobre:
    </p>
    <ul>
      <li>
        Acumula&#231;&#227;o de cargos
      </li>
      <li>
        Os deveres
      </li>
      <li>
        As proibi&#231;&#245;es
      </li>
      <li>
        As responsabilidades dos servidores
      </li>
      <li>
        Penalidades a eles aplic&#225;veis
      </li>
    </ul>
    <p>
      Nesta aula ser&#225; visto a respeito da acumula&#231;&#227;o de cargos.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1564858702096" FOLDED="true" ID="ID_625457295" MODIFIED="1565207167217" POSITION="right" STYLE="bubble" TEXT="1. Acumula&#xe7;&#xe3;o dos Cargos">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1564858714360" FOLDED="true" ID="ID_1101730088" MODIFIED="1565204018537" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      &#233; vedada a acumula&#231;&#227;o remunerada de cargo
    </p>
    <p style="text-align: center">
      com outro cargo, emprego ou fun&#231;&#227;o p&#250;blicos
    </p>
    <p style="text-align: center">
      abrangendo:
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#338800" CREATED="1564858829501" ID="ID_267437984" MODIFIED="1564859190274" TEXT="Administra&#xe7;&#xe3;o Direta"/>
<node COLOR="#338800" CREATED="1564858840466" ID="ID_1074458005" MODIFIED="1564859190274" TEXT="Autarquias"/>
<node COLOR="#338800" CREATED="1564858846099" ID="ID_159713346" MODIFIED="1564859190274" TEXT="Funda&#xe7;&#xf5;es"/>
<node COLOR="#338800" CREATED="1564858852883" ID="ID_1594664133" MODIFIED="1564859190274" TEXT="Empresas P&#xfa;blicas"/>
<node COLOR="#338800" CREATED="1564858854699" ID="ID_1634185377" MODIFIED="1564859190273" TEXT="Sociedades de Economia Mista"/>
<node COLOR="#338800" CREATED="1564858890988" ID="ID_1297198211" MODIFIED="1564859190272">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      Sociedades Controladas<br />pelo poder p&#250;blico
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#0033ff" CREATED="1564858950015" HGAP="19" ID="ID_1284628520" MODIFIED="1564859402978" STYLE="bubble" TEXT="exceto, quando houver compatibilidade de hor&#xe1;rios:" VSHIFT="16">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006633" CREATED="1564858974562" ID="ID_592731081" MODIFIED="1564859551977" TEXT="Dois cargos/empregos de professor"/>
<node COLOR="#006633" CREATED="1564859011697" ID="ID_82768053" MODIFIED="1564859551976">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      Um cargo/emprego como professor<br />e outro t&#233;cnico-cient&#237;fico
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006633" CREATED="1564859044682" ID="ID_972011438" MODIFIED="1564859551974">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      Dois cargos/empregos privativos<br />de m&#233;dico
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#ff0000" CREATED="1564859217010" FOLDED="true" ID="ID_1277380037" MODIFIED="1565204027417" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      O estatuto <u><b>veda</b></u>&#160;&#224; percep&#231;&#227;o simultanea
    </p>
    <p style="text-align: center">
      de proventos com a remunera&#231;&#227;o do cargo,
    </p>
    <p style="text-align: center">
      emprego ou fun&#231;&#227;o p&#250;blica
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1564859390867" ID="ID_1561187995" MODIFIED="1565204022412" TEXT="ressalvadas a hip&#xf3;teses:">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006633" CREATED="1564859425333" ID="ID_45395496" MODIFIED="1564859544857" TEXT="acumula&#xe7;&#xe3;o permitida na atividade">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006633" CREATED="1564859438371" ID="ID_1818676815" MODIFIED="1564859544857" TEXT="exerc&#xed;cio de mandado eletivo">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006633" CREATED="1564859446297" ID="ID_873922830" MODIFIED="1564859544857" TEXT="cargo em comiss&#xe3;o">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006633" CREATED="1564859451677" ID="ID_884121861" MODIFIED="1564859544855">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      contrato para presta&#231;&#227;o de servi&#231;os<br />de natureza t&#233;cnica ou especializada
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1565029912957" FOLDED="true" ID="ID_870555816" MODIFIED="1565207167217" POSITION="right" STYLE="bubble" TEXT="2. Deveres dos Servidores">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1565029924779" ID="ID_1556300775" MODIFIED="1565030363838" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Os deveres possuem um <u>car&#225;ter gen&#233;rico</u>
    </p>
    <p>
      De acordo com o art. 149 do Estatuto, s&#227;o deveres do Funcion&#225;rio p&#250;blico do Estado do Amazonas:
    </p>
    <p>
      
    </p>
    <ul>
      <li>
        Lealdade e respeito &#224;s institui&#231;&#245;es constitucionais e administrativas;
      </li>
      <li>
        Assiduidade e pontualidade;
      </li>
      <li>
        Cumprimento de ordens superiores, <b><font color="#ff0000">representando quando manifestamente ilegais;</font></b>
      </li>
      <li>
        &#160;Desempenho, com zelo e presteza, dos trabalhos de sua incumb&#234;ncia;
      </li>
      <li>
        Sigilo sobre os assuntos da reparti&#231;&#227;o;
      </li>
      <li>
        Zelo pela economia do material e pela conserva&#231;&#227;o do patrim&#244;nio sob sua guarda ou para sua utiliza&#231;&#227;o;
      </li>
      <li>
        Urbanidade com companheiros de servi&#231;os e o p&#250;blico geral
      </li>
      <li>
        Coopera&#231;&#227;o e esp&#237;rito de solidariedade com os companheiros de trabalho;
      </li>
      <li>
        Conhecimento das leis, regulamentos, regimentos, instru&#231;&#245;es e ordens de servi&#231;os referentes &#224;s suas fun&#231;&#245;es;
      </li>
      <li>
        Procedimento compat&#237;vel com a dignidade da fun&#231;&#227;o p&#250;blica.
      </li>
    </ul>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565030080559" FOLDED="true" ID="ID_154921462" MODIFIED="1565033968954" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; Os servidores t&#234;m o dever de cumprir as ordens emanadas de seus superiores;
    </p>
    <p>
      
    </p>
    <p>
      &gt; Tal dever &#233; decorr&#234;ncia natural do poder hier&#225;rquico;
    </p>
    <p>
      
    </p>
    <p>
      &gt; Entretanto,o Estatuto estabelece uma importante ressalva: a
    </p>
    <p>
      hip&#243;tese de a ordem ser <b><font color="#ff0000">manifestamente ilegal.</font></b>
    </p>
  </body>
</html></richcontent>
<node COLOR="#009999" CREATED="1565030157573" ID="ID_223026468" MODIFIED="1565030279611" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      No caso de receber uma ordem manifestamente ilegal:
    </p>
    <p>
      
    </p>
    <ul>
      <li>
        O servidor deve abster-se de cumpri-la
      </li>
      <li>
        Tem o dever de representar contra o seu superior
      </li>
    </ul>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1565030295994" FOLDED="true" ID="ID_1434255304" MODIFIED="1565207292976" POSITION="right" STYLE="bubble" TEXT="3. Proibi&#xe7;&#xf5;es aos servidores">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1565030401966" ID="ID_1166776551" MODIFIED="1565207167217">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; Art. 150
    </p>
    <p>
      
    </p>
    <p>
      &gt; Proibi&#231;&#245;es possuem um car&#225;ter espec&#237;fico, que uma vez infrigidas, acarretam para o servidor penalidades determinadas,
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565030474621" HGAP="21" ID="ID_1875282822" MODIFIED="1565207244288" TEXT="Ao funcion&#xe1;rio &#xe9; PROIBIDO: " VSHIFT="27">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1565030546735" ID="ID_1559098579" MODIFIED="1565034102677">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Referir-se de modo depreciativo/desrespeitoso em:
    </p>
    <p>
      
    </p>
    <p>
      &gt; em informa&#231;&#227;o
    </p>
    <p>
      &gt; parecer ou despacho
    </p>
    <p>
      &gt; &#224;s autoridades
    </p>
    <p>
      &gt; a atos da Administra&#231;&#227;o P&#250;blica
    </p>
  </body>
</html></richcontent>
<node COLOR="#ff0000" CREATED="1565030707411" ID="ID_924238287" MODIFIED="1565030981579">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      podendo, por&#233;m, em trabalho assinado, critic&#225;-los do ponto de vista:
    </p>
    <ul>
      <li>
        &#160;doutrin&#225;rio ou da organiza&#231;&#227;o do servi&#231;o;
      </li>
    </ul>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#006699" CREATED="1565030765235" HGAP="25" ID="ID_791053860" MODIFIED="1565204082368" VSHIFT="29">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Censurar as autoridades constitu&#237;das
    </p>
    <p>
      
    </p>
    <p>
      &gt; por qualquer &#243;rg&#227;o de divulga&#231;&#227;o p&#250;blica
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565030847946" ID="ID_23397886" MODIFIED="1565034102674" VSHIFT="23">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pleitear, como procurador ou intermedi&#225;rio<br />junto &#224;s reparti&#231;&#245;es p&#250;blicas
    </p>
  </body>
</html></richcontent>
<node COLOR="#ff0000" CREATED="1565030921166" ID="ID_1804431734" MODIFIED="1565030981584">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Salvo quando se tratar de:
    </p>
    <p>
      
    </p>
    <ul>
      <li>
        percep&#231;&#227;o de vencimentos; e
      </li>
      <li>
        proventos do c&#244;njuge, companheiro; ou
      </li>
      <li>
        parente consangu&#237;neo ou afim, at&#233; segundo grau;
      </li>
    </ul>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1565031001067" ID="ID_1340591624" MODIFIED="1565034102673">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Retirar, modificar ou substituir, <b><font color="#ff0000">sem pr&#233;via autoriza&#231;&#227;o</font></b>,<br />&#160;qualquer documento de &#243;rg&#227;o estadual;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031065443" HGAP="18" ID="ID_342559713" MODIFIED="1565204117608" VSHIFT="10">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Empregar materiais e bens do Estado em servi&#231;o particular ou, sem autoriza&#231;&#227;o superior, retirar objetos de &#243;rg&#227;os oficiais;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031082729" HGAP="21" ID="ID_408707011" MODIFIED="1565204120392" VSHIFT="17">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Valer-se do cargo para lograr proveito pessoal;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031091159" HGAP="17" ID="ID_39167822" MODIFIED="1565204127960" VSHIFT="13">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Coagir ou aliciar subordinados com objetivo de natureza partid&#225;ria;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031104164" HGAP="23" ID="ID_437126186" MODIFIED="1565204130408" VSHIFT="10">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Receber propinas, comiss&#245;es, presentes e vantagens de qualquer esp&#233;cie, em raz&#227;o do cargo;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031118058" HGAP="18" ID="ID_1941240953" MODIFIED="1565204132384" VSHIFT="17">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Praticar a usura, em qualquer de suas formas;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031223343" ID="ID_405947843" MODIFIED="1565204136208" VSHIFT="24">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Promover manifesta&#231;&#245;es de apre&#231;o ou desapre&#231;o, mesmo para obsequiar superiores hier&#225;rquicos, e fazer circular ou subscrever lista de donativos na reparti&#231;&#227;o;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031230403" HGAP="21" ID="ID_1792764960" MODIFIED="1565204138704" VSHIFT="22">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Cometer a pessoa estranha &#224; reparti&#231;&#227;o, fora dos casos previstos em lei, o
    </p>
    <p>
      desempenho de encargos de sua compet&#234;ncia ou de seus subordinados.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031238982" HGAP="18" ID="ID_1327068211" MODIFIED="1565204141440" VSHIFT="25">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Participar da diretoria, ger&#234;ncia, administra&#231;&#227;o, conselho-t&#233;cnico ou administrativo de empresa ou sociedade:
    </p>
    <ul>
      <li>
        Contratante ou concession&#225;ria de servi&#231;o p&#250;blico;
      </li>
      <li>
        Fornecedora de equipamento ou material de qualquer natureza ou esp&#233;cie, a qualquer &#243;rg&#227;o estadual;
      </li>
      <li>
        Com atividades relacionadas &#224; natureza do cargo ou fun&#231;&#227;o p&#250;blica exercida;
      </li>
    </ul>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031295725" HGAP="19" ID="ID_1309854780" MODIFIED="1565204143824" VSHIFT="19">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Exercer o com&#233;rcio ou participar de sociedade comercial, exceto como acionistas, cotistas ou comandit&#225;rio;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031313769" ID="ID_1284833139" MODIFIED="1565204148088" VSHIFT="13">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Entreter-se, nos locais e horas de trabalho, em palestras, leituras ou atividades estranhas ao servi&#231;o;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031345311" ID="ID_803156704" MODIFIED="1565204149680" VSHIFT="19">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Atender pessoas estranhas ao servi&#231;o no local de trabalho, para tratar de assuntos particulares;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031363872" ID="ID_410956527" MODIFIED="1565204152712" VSHIFT="14">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Incitar greves ou delas participar ou praticar atos de sabotagem contra o servi&#231;o p&#250;blico;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031374341" HGAP="23" ID="ID_1978832567" MODIFIED="1565204157376" VSHIFT="15">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fundar sindicato de funcion&#225;rio ou dele participar; e
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006699" CREATED="1565031406436" HGAP="18" ID="ID_894584666" MODIFIED="1565204159384" VSHIFT="16">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ausentar-se do Estado, mesmo para estudo ou miss&#227;o oficial de qualquer natureza, com ou sem &#244;nus para os cofres p&#250;blicos, sem autoriza&#231;&#227;o expressa do Chefe do Poder a cujo Quadro de Pessoal integre.
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1565031460203" ID="ID_917513384" MODIFIED="1565207167218" POSITION="right" STYLE="bubble" TEXT="4. Responsabilidades dos servidores">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1565031471988" ID="ID_1564909206" MODIFIED="1565207167218">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Regra geral </b>
    </p>
    <p>
      
    </p>
    <p>
      &gt; O servidor responde pelo exerc&#237;cio irregular nas esferas
    </p>
    <ul>
      <li>
        Civil
      </li>
      <li>
        Penal
      </li>
      <li>
        Administrativa
      </li>
    </ul>
  </body>
</html></richcontent>
<node CREATED="1565032533813" ID="ID_341223066" MODIFIED="1565207167218" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="../../../../Legislação%20TJ%20AM/Estatuto%20dos%20Servidores/sancoes.png" />
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1565032562051" ID="ID_1741885278" MODIFIED="1565207167219" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; As san&#231;&#245;es<b>&#160;poder&#227;o acumular-se</b>, umas e outras, <b>independentes entre si; </b>
    </p>
    <p>
      
    </p>
    <p>
      &gt; A indeniza&#231;&#227;o <b><font color="#ff0000">no m&#225;ximo 10%</font></b>&#160;do vencimento ou remunera&#231;&#227;o;
    </p>
    <p>
      
    </p>
  </body>
</html></richcontent>
</node>
<node BACKGROUND_COLOR="#39de26" CREATED="1565032924893" HGAP="19" ID="ID_473866101" MODIFIED="1565207167219" STYLE="bubble" VSHIFT="32">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; Tratando-se de danos causados <b><font color="#005aff">a terceiros</font></b>&#160;, responder&#225;<br />o funcion&#225;rio perante a Fazenda P&#250;blica, <font color="#ff0000"><b>em a&#231;&#227;o regressiva</b></font>,<br />proposta <u>depois de transitada em julgado</u>&#160;a decis&#227;o que houver<br />condenado a Fazenda a indenizar o prejudicado.
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="messagebox_warning"/>
<node COLOR="#990099" CREATED="1565033422556" ID="ID_1329353169" MODIFIED="1565207167219">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; A responsabilidade civil de agentes p&#250;blicos &#233; do tipo subjetiva, <b><font color="#ff0000">por culpa comum; </font></b>
    </p>
    <p>
      
    </p>
    <p>
      &gt; Eles s&#243; respondem pelos danos que causarem, se o Estado provar que houve culpa ou dolo (inten&#231;&#227;o) do servidor.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#990099" CREATED="1565033387404" ID="ID_1641598273" MODIFIED="1565207167220">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; <u>A a&#231;&#227;o do Estado contra o agente p&#250;blico &#233; denominada a&#231;&#227;o regressiva.</u>
    </p>
    <p>
      
    </p>
    <p>
      &gt; A a&#231;&#227;o dita regressiva &#233; sempre uma segunda a&#231;&#227;o;
    </p>
    <p>
      
    </p>
    <p>
      &gt; Depois que a a&#231;&#227;o foi transitada em julgado, o estado pode entrar com uma a&#231;&#227;o contra o servidor em vista de obter o ressarcimento do valor que foi condenado a indenizar;
    </p>
    <p>
      
    </p>
    <p>
      <u>&gt; o Estado ter&#225; que provar que houve culpa ou dolo do agente</u>&#160; e, s&#243; se conseguir provar, ser&#225; reconhecida a responsabilidade civil do agente perante o Estado.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node CREATED="1565033837012" FOLDED="true" ID="ID_287055030" MODIFIED="1565207167222" POSITION="right" STYLE="bubble" TEXT="5. Penas Disciplinares">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1565204277279" ID="ID_95495728" MODIFIED="1565206822286">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; Art 156
    </p>
    <p>
      
    </p>
    <p>
      &gt; S&#227;o Penas Disciplinares:
    </p>
    <ul>
      <li>
        Repreens&#227;o
      </li>
      <li>
        Suspens&#227;o
      </li>
      <li>
        Demiss&#227;o
      </li>
      <li>
        Cassa&#231;&#227;o de Aposentadoria ou Disponibilidade
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node COLOR="#006699" CREATED="1565204707949" ID="ID_675536941" MODIFIED="1565205070728">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Repreens&#227;o: </b>
    </p>
    <p>
      
    </p>
    <p>
      A pena de repreens&#227;o <u>ser&#225; aplicada por escrito</u>, nos casos de
    </p>
    <ul>
      <li>
        indisciplina ou
      </li>
      <li>
        falta de cumprimento dos deveres funcionais.
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#006699" CREATED="1565204771465" FOLDED="true" HGAP="18" ID="ID_108969533" MODIFIED="1565206836373" VSHIFT="14">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Suspens&#227;o: </b>
    </p>
    <p>
      
    </p>
    <p>
      Ser&#225;&#160;&#160;aplicada nos casos de:
    </p>
    <ul>
      <li>
        <font color="#ff0000">falta grave; </font>
      </li>
      <li>
        <font color="#ff0000">reincid&#234;ncia;</font>
      </li>
      <li>
        <font color="#0001ff">n&#227;o exceder&#225; 90 dias;</font>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node COLOR="#006699" CREATED="1565205016425" ID="ID_1161767700" MODIFIED="1565205074953">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>O funcion&#225;rio suspenso <font color="#ff0000">perder&#225;</font>&#160;, d<u>urante o per&#237;odo de cumprimento da pena</u>, <font color="#ff0000">todos os direitos e vantagens decorrentes do exerc&#237;cio do cargo.</font></b>
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#006699" CREATED="1565205160300" ID="ID_1770536748" MODIFIED="1565205342656">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; As penas de <b><font color="#ff0000">repreens&#227;o</font></b>&#160;e <b><font color="#ff0000">suspens&#227;o</font></b>&#160; <b><font color="#0003ff">at&#233; 05 dias</font></b>&#160;ser&#227;o <b>aplicadas</b>&#160;de<br />&#160;<u>imediato</u>&#160; pela autoridade que tiver conhecimento direto de falta cometida.
    </p>
    <p>
      
    </p>
    <p>
      &gt; O ato ter&#225; efeito <u>imediato</u>, mas <u>provis&#243;rio</u>
    </p>
    <p>
      
    </p>
    <p>
      &gt; O funcion&#225;rio tem direito de <u>oferecer defesa por escrito</u>, no prazo de <b><font color="#001aff">03 dias</font></b>
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1565205343613" ID="ID_693124954" MODIFIED="1565205519672" VSHIFT="27">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; <b><font color="#ff0000">Ser&#227;o consideradas como de suspens&#227;o</font>&#160;os dias em que o funcion&#225;rio <font color="#ff0000">deixar de atender</font>, <u>sem motivo justificado</u>, <font color="#ff0000">&#224; convoca&#231;&#227;o do j&#250;ri e outros servi&#231;os obrigat&#243;rios previstos em lei.</font></b>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#006699" CREATED="1565205531567" HGAP="19" ID="ID_538784657" MODIFIED="1565206840672" VSHIFT="24">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Demiss&#227;o: </b>
    </p>
    <p>
      
    </p>
    <p>
      A pena de demiss&#227;o ser&#225; aplicada nos casos de:
    </p>
    <ul>
      <li>
        crime contra a administra&#231;&#227;o p&#250;blica, <b><font color="#ff0000">assim definido na Lei Penal;</font></b>
      </li>
      <li>
        abandono de cargo;(mais de 30 dias consecutivos)
      </li>
      <li>
        inassiduidade habitual(mais de 60 dias em um ano)
      </li>
      <li>
        improbidade administrativa;
      </li>
      <li>
        incontin&#234;ncia p&#250;blica e escandalosa e pr&#225;tica de jogos proibidos;
      </li>
      <li>
        insubordina&#231;&#227;o grave em servi&#231;o;
      </li>
      <li>
        ofensa f&#237;sica em servi&#231;o, contra funcion&#225;rio ou particular, <b><font color="#ff0000">salvo em leg&#237;tima defesa&#160;e em estrito cumprimento do dever legal;</font></b>
      </li>
      <li>
        aplica&#231;&#227;o irregular de dinheiro p&#250;blico;
      </li>
      <li>
        revela&#231;&#227;o de fato ou informa&#231;&#227;o de natureza sigilosa que o funcion&#225;rio conhe&#231;a <b><font color="#ff0000">em raz&#227;o do cargo;</font></b>
      </li>
      <li>
        corrup&#231;&#227;o passiva <b><font color="#ff0000">nos termos da lei penal;</font></b>
      </li>
      <li>
        les&#227;o aos cofres p&#250;blicos e dilapida&#231;&#227;o do patrim&#244;nio estadual;
      </li>
      <li>
        ocorr&#234;ncia de qualquer das veda&#231;&#245;es previstas no, art. 144 (acumula&#231;&#227;o de cargos), <b><font color="#ff0000">se provada a m&#225;-f&#233;</font></b>;
      </li>
      <li>
        transgress&#227;o de quaisquer das seguintes proibi&#231;&#245;es (incisos IV, V, VI, VII e IX, art. 150):
      </li>
    </ul>
    <p>
      IV - Retirar, modificar ou substituir, sem pr&#233;via autoriza&#231;&#227;o, qualquer documento de &#243;rg&#227;o estadual;
    </p>
    <p>
      V - Empregar materiais e bens do Estado em servi&#231;o particular ou, sem autoriza&#231;&#227;o superior, retirar objetos de &#243;rg&#227;os oficiais;
    </p>
    <p>
      VI - Valer-se do cargo para lograr proveito pessoal;
    </p>
    <p>
      VII - Coagir ou aliciar subordinados com objetivo de natureza partid&#225;ria;
    </p>
    <p>
      IX - Praticar a usura, em qualquer de suas formas;
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#006699" CREATED="1565206176996" HGAP="21" ID="ID_90722681" MODIFIED="1565206853848" VSHIFT="20">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Cassa&#231;&#227;o da aposentadoria ou da disponibilidade: </b>
    </p>
    <p>
      
    </p>
    <p>
      &gt; Ser&#225; cassada a <b>aposentadoria</b>&#160;ou a <b>disponibilidade</b>&#160; do inativo que praticou, quando em atividade, falta pun&#237;vel com <u>demiss&#227;o</u>.
    </p>
    <p>
      
    </p>
    <p>
      &gt; Ser&#225; cassada a <b>disponibilidade</b>&#160;quando funcion&#225;rio:
    </p>
    <ul>
      <li>
        investiu-se <b><font color="#ff0000">ilegalmente</font></b>&#160;em cargo ou fun&#231;&#227;o p&#250;blica;
      </li>
      <li>
        Aceitou comiss&#227;o, emprego ou pens&#227;o de <u>Estado estrangeiro</u>, <b><font color="#ff0000">sem pr&#233;via e expressa autoriza&#231;&#227;o do Presidente da Rep&#250;blica.</font></b>
      </li>
    </ul>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1565206495407" ID="ID_1209747927" MODIFIED="1565206537386">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &gt; Ser&#225; igualmente cassada a disponibilidade do funcion&#225;rio<br /><b><font color="#ff0000">que n&#227;o assumir no prazo legal o exerc&#237;cio do cargo </font></b><br /><b><font color="#ff0000">em que for aproveitado.</font></b>
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1565204454181" HGAP="24" ID="ID_1001807448" MODIFIED="1565206857584" VSHIFT="14">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>&gt; Na aplica&#231;&#227;o de penalidade ser&#227;o considerados:</b>
    </p>
    <p>
      
    </p>
    <ul>
      <li>
        a <b><u><font color="#ff0000">natureza</font></u></b>&#160;e a <b><font color="#ff0000">gravidade</font></b>&#160;da <u>infra&#231;&#227;o</u>;
      </li>
      <li>
        os <font color="#ff0000"><b>danos que dela resultarem para o servi&#231;o p&#250;blico;</b></font>
      </li>
      <li>
        os <font color="#ff0000"><b>antecedentes funcionais do servidor;</b></font>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#006699" CREATED="1565206597796" HGAP="26" ID="ID_1171062128" MODIFIED="1565206861896" VSHIFT="18">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      &gt; Nenhuma discricionariedade existe quanto ao dever de punir<br />quem comprovadamente tenha praticado uma infra&#231;&#227;o<br />disciplinar.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#0033ff" CREATED="1565206661586" FOLDED="true" HGAP="19" ID="ID_1024959607" MODIFIED="1565206863967" TEXT="S&#xe3;o competentes para aplica&#xe7;&#xe3;o das penalidades disciplinares:" VSHIFT="25">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1565206667687" ID="ID_1219917935" MODIFIED="1565206747222">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="penalidades.png" />
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node CREATED="1565033816052" ID="ID_1087728369" MODIFIED="1565207167222" POSITION="right" TEXT="6. Prescri&#xe7;&#xe3;o da Punibilidade">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#338800" CREATED="1565207017711" ID="ID_1598227361" MODIFIED="1565207167223" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="text-align: center">
      <b>Em seu art. 168, a Lei AM no 1.762/1986 estabelece<br />que a a&#231;&#227;o disciplinar prescreve -&gt;</b>
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1565207043192" ID="ID_927650198" MODIFIED="1565207167223">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="prescricao.png" />
  </body>
</html>
</richcontent>
</node>
<node COLOR="#006699" CREATED="1565207136238" ID="ID_1484473540" MODIFIED="1565207167223" TEXT="&gt; A prescri&#xe7;&#xe3;o come&#xe7;a a contar da data em que a autoridade&#xa; tomar conhecimento da exist&#xea;ncia da falta.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
</map>
